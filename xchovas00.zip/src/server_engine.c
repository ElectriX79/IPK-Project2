//
// Created by electrix on 4/30/26.
//

#include "../include/server_engine.h"
#include "../include/checksum.h"
#include "../include/read_write_engine.h"

#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <errno.h>

int server_engine(int sock_id, struct config *cfg) {

    if (sock_id < 0) {
        fprintf(stderr, "Invalid socket\n");
        return -1;
    }

    FILE *output = NULL;

    if (strcmp(cfg->output_file, "-") == 0) {
        output = stdout;
    } else {
        output = fopen(cfg->output_file, "wb");
        if (!output) {
            perror("fopen");
            return -1;
        }
    }

    uint32_t expected_seq = 0;

    struct sockaddr_storage client_addr;
    socklen_t addr_len = sizeof(client_addr);

    struct packet pkt;

    while (1) {

        ssize_t n = recvfrom(
            sock_id,
            &pkt,
            sizeof(pkt),
            0,
            (struct sockaddr *)&client_addr,
            &addr_len
        );

        if (n < 0) {
            if (errno == EWOULDBLOCK || errno == EAGAIN) {
                continue;
            }
            perror("recvfrom");
            break;
        }

        // --- checksum ---
        uint32_t recv_checksum = pkt.hdr.checksum;
        pkt.hdr.checksum = 0;

        if (compute_checksum(&pkt, n) != recv_checksum) {
            continue; // zahodiť
        }

        // --- konverzia ---
        uint32_t conn_id = ntohl(pkt.hdr.connection_id);
        uint32_t seq = ntohl(pkt.hdr.seq_num);
        uint16_t data_len = ntohs(pkt.hdr.data_len);

        // --- DATA packet ---
        if (pkt.hdr.flags & DATA) {

            if (seq == expected_seq) {

                // zapis
                write_to_file(output, pkt.payload, data_len, expected_seq * DATA_LEN);

                expected_seq++;
            }

            // --- ACK ---
            struct rdt_header ack = {0};

            ack.connection_id = htonl(conn_id);
            ack.ack = htonl(expected_seq - 1);
            ack.flags = ACK;
            ack.data_len = 0;

            ack.checksum = 0;
            ack.checksum = compute_checksum(&ack, sizeof(ack));

            sendto(
                sock_id,
                &ack,
                sizeof(ack),
                0,
                (struct sockaddr *)&client_addr,
                addr_len
            );
        }

        // --- FIN (ukončenie) ---
        if (pkt.hdr.flags & FIN) {

            struct rdt_header fin_ack = {0};

            fin_ack.connection_id = htonl(conn_id);
            fin_ack.flags = ACK | FIN;
            fin_ack.checksum = 0;

            fin_ack.checksum = compute_checksum(&fin_ack, sizeof(fin_ack));

            sendto(
                sock_id,
                &fin_ack,
                sizeof(fin_ack),
                0,
                (struct sockaddr *)&client_addr,
                addr_len
            );

            break;
        }
    }

    if (output && output != stdout) {
        fclose(output);
    }

    return 0;
}